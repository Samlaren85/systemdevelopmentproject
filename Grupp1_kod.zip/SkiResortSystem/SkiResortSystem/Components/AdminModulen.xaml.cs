﻿using System.Windows.Controls;

namespace SkiResortSystem.Components
{
    /// <summary>
    /// Interaction logic for AdminModulen.xaml
    /// Denna modul är inte implementerad i systemet
    /// </summary>
    public partial class AdminModulen : UserControl
    {
        public AdminModulen()
        {
            InitializeComponent();
        }
    }
}

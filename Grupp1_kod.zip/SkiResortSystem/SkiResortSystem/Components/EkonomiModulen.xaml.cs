﻿using System.Windows.Controls;

namespace SkiResortSystem.Components
{
    /// <summary>
    /// Interaction logic for EkonomiModulen.xaml
    /// </summary>
    public partial class EkonomiModulen : UserControl
    {
        public EkonomiModulen()
        {
            InitializeComponent();
        }

    }
}

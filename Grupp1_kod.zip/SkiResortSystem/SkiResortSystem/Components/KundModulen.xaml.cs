﻿using System.Windows.Controls;

namespace SkiResortSystem.Components
{
    /// <summary>
    /// Interaction logic for KundModulen.xaml
    /// </summary>
    public partial class KundModulen : UserControl
    {
        public KundModulen()
        {
            InitializeComponent();
        }

    }
}

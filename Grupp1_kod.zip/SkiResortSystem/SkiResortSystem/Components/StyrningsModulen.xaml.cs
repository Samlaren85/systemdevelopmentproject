﻿using System.Windows.Controls;

namespace SkiResortSystem.Components
{
    /// <summary>
    /// Interaction logic for StyrningsModulen.xaml
    /// </summary>
    public partial class StyrningsModulen : UserControl
    {
        public StyrningsModulen()
        {
            InitializeComponent();
        }
    }
}

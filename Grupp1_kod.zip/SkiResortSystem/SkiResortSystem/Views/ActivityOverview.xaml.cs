﻿using SkiResortSystem.Services;
using System.Windows;

namespace SkiResortSystem.Views
{
    /// <summary>
    /// Interaction logic for ActivityOverview.xaml
    /// </summary>
    public partial class ActivityOverview : Window, ICloseable
    {
        public ActivityOverview()
        {
            InitializeComponent();
        }
    }
}

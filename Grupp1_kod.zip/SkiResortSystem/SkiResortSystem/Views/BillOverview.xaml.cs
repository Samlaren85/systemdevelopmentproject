﻿using SkiResortSystem.Services;
using System.Windows;

namespace SkiResortSystem.Views
{
    /// <summary>
    /// Interaction logic for BillOverview.xaml
    /// </summary>
    public partial class BillOverview : Window, ICloseable
    {
        public BillOverview()
        {
            InitializeComponent();
        }
    }
}

﻿using SkiResortSystem.Services;
using System.Windows;

namespace SkiResortSystem.Views
{
    /// <summary>
    /// Interaction logic for BookingOverview.xaml
    /// </summary>
    public partial class BookingOverview : Window, ICloseable
    {
        public BookingOverview()
        {
            InitializeComponent();
        }

      
    }
}

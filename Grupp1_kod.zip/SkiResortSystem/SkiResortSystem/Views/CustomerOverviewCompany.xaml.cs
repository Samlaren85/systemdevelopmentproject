﻿using SkiResortSystem.Services;
using System.Windows;

namespace SkiResortSystem.Views
{
    /// <summary>
    /// Interaction logic for KundöversiktFöretag.xaml
    /// </summary>
    public partial class CustomerOverviewCompany : Window, ICloseable
    {
        public CustomerOverviewCompany()
        {
            InitializeComponent();
        }
    }
}

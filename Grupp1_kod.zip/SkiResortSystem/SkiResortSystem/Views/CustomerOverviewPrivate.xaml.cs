﻿using SkiResortSystem.Services;
using System.Windows;

namespace SkiResortSystem.Views
{
    /// <summary>
    /// Interaction logic for Kundöversikt.xaml
    /// </summary>
    public partial class CustomerOverviewPrivate : Window, ICloseable
    {
        public CustomerOverviewPrivate()
        {
            InitializeComponent();
        }
    }
}

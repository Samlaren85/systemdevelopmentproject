﻿using SkiResortSystem.Services;
using System.Windows;

namespace SkiResortSystem.Views
{
    /// <summary>
    /// Interaction logic for EquipmentOverview.xaml
    /// </summary>
    public partial class EquipmentOverview : Window, ICloseable
    {
        public EquipmentOverview()
        {
            InitializeComponent();
        }
    }
}

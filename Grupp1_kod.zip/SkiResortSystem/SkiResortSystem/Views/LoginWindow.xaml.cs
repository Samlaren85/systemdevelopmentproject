﻿using SkiResortSystem.Services;
using System.Windows;

namespace SkiResortSystem.Views
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window, ICloseable
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
    }
}

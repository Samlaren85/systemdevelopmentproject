﻿using SkiResortSystem.Services;
using System.Windows;

namespace SkiResortSystem.Views
{
    /// <summary>
    /// Interaction logic for StatisticsOverview.xaml
    /// </summary>
    public partial class StatisticsOverview : Window, ICloseable
    {
        public StatisticsOverview()
        {
            InitializeComponent();
        }
    }
}
